# What is ComfyScript?

ComfyScript is a collection of pre-written Python scripts written for each Raspberry Pi components. It's automatically saved and updated in a folder in your Raspberry Pi. This is used by the pre-built buttons in ComfySpace.