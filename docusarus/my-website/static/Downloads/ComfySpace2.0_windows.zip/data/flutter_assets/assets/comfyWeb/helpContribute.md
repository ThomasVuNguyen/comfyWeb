# Want to help contribute?
ComfySpace is a brain-child project of mine for a long time now.

ComfySpace apps are built with Flutter, ComfyScript is written in Python, and ComfyRobo is primarily designed in OnShape.

If you find the project interesting and would like to help contribute, we always need help to make the system more useful no matter if you are a user, enthusiat, programmer, or engineer.

Got an feature suggestion/idea? //put link 
Found a bug needs fixing? //put link
Want to help with the codebase? //put link

Thank you.