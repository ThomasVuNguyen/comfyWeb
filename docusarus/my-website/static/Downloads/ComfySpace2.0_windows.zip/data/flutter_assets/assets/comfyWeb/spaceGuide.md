# What is a space?

A space is a control interface to control a specific Raspberry Pi.
This is a client-host SSH connection between your phone/computer and the Raspberry Pi

# Create a new space
When first using the app, you can create a new space

//enter your space name, hostname, username, and password for SSH connection

Typically, this is the information setup in the Raspberry Pi Imager application.

//put raspberry pi setup link

# Edit a space

Press on the edit button to delete or edit information about a space

