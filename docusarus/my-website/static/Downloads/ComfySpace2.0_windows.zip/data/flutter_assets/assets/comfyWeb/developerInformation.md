# Lead Developer

Thomas Nguyen //put a pic
I have worked in many industries and studied in many disciplines. I have a Bachelor's in Mechanical Engineering and have worked in Manufacturing (Sonoco), EV (Tesla), and MEP (RGD Engineers). But even before Mechanical Engineering, I have always had a passion for programming and robotics.
Above all, I have always loved the art of making. 
ComfyScript is the culmination of many problems previously assessed and solved by me.
I started learning Flutter & Mobile development to develop ComfySpace in March-2023 and have loved every second of it

