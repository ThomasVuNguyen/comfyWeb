# What is comfyRobo?

comfyRobo is a collection of pre-built and customizable Raspberry Pi projects. 
Having worked with Raspberry Pi for a long time, I have always believed there is so much untapped potential in the power and openness of Raspberry Pi.